"use client";

import { K7PhotoUpload } from "@/components/k7-photo-upload";
import { sectionTemplates, type PublicationSection } from "@/lib/publication-templates";
import { stableSnapshot } from "@/lib/stable-snapshot";
import { useK7Sync } from "@/components/use-k7-sync";
import { BrandLabel } from "@/components/brand-label";

import { useCallback, useEffect, useRef, useState, type FormEvent, type ReactNode } from "react";
import { Edit3, Plus, Pin, Trash2, Eye, X, Bold, Italic, List, Heading2, Quote, ExternalLink } from "lucide-react";

type News = {
  id: string; title: string; subtitle: string | null; category: string; content: string;
  cover_url: string | null; published_at: string; layout_style: "editorial" | "statement" | "spotlight";
  section?: PublicationSection; media_urls?: string[]; is_pinned: boolean; cta_label: string | null; cta_url: string | null;
};
const blank = { mediaUrls: [] as string[], title: "", subtitle: "", category: "НОВОСТИ", content: "", coverUrl: "", layoutStyle: "editorial" as News["layout_style"], pinned: false, ctaLabel: "", ctaUrl: "" };
type Draft = typeof blank;

async function json(path: string, init?: RequestInit) {
  const response = await fetch(path, { cache: "no-store", credentials: "include", ...init });
  const data = await response.json();
  if (!response.ok || !data.success) throw new Error(data.error ?? `HTTP ${response.status}`);
  return data;
}

function inlineText(text: string): ReactNode[] {
  // Text stays escaped in React. Only HTTPS hyperlinks are clickable.
  const chunks = text.split(/(\*\*[^*]+\*\*|\*[^*]+\*|\[[^\]]+\]\(https:\/\/[^\s)]+\))/g);
  return chunks.map((part, index) => {
    if (part.startsWith("**") && part.endsWith("**")) return <strong key={index}>{part.slice(2,-2)}</strong>;
    if (part.startsWith("*") && part.endsWith("*")) return <em key={index}>{part.slice(1,-1)}</em>;
    const link = part.match(/^\[([^\]]+)\]\((https:\/\/[^\s)]+)\)$/);
    if (link) return <a key={index} href={link[2]} target="_blank" rel="noopener noreferrer">{link[1]}</a>;
    return <span key={index}>{part}</span>;
  });
}

function EditorialBody({ value }: { value: string }) {
  const lines = value.split(/\r?\n/);
  return <div className="k7-editorial-body">{lines.map((line, index) => {
    const trimmed = line.trim();
    if (!trimmed) return <div key={index} className="k7-editorial-spacer" aria-hidden="true" />;
    if (trimmed.startsWith("## ")) return <h4 key={index}>{inlineText(trimmed.slice(3))}</h4>;
    if (trimmed.startsWith("> ")) return <blockquote key={index}>{inlineText(trimmed.slice(2))}</blockquote>;
    if (/^[-•] /.test(trimmed)) return <p key={index} className="k7-editorial-bullet">{inlineText(trimmed.slice(2))}</p>;
    return <p key={index}>{inlineText(trimmed)}</p>;
  })}</div>;
}

function NewsCard({ item, canManage, onEdit, onDelete, onPin, busy }: {
  item: News; canManage: boolean; onEdit: (item: News) => void;
  onDelete: (id: string) => void; onPin: (item: News) => void; busy: boolean;
}) {
  const [confirming, setConfirming] = useState(false);
  return <article className={`k7-news-story k7-news-${item.layout_style}`}>
    <div className="k7-story-kicker"><span>{item.category || "НОВОСТИ"}</span><span>{item.is_pinned && <><Pin size={12}/> ЗАКРЕПЛЕНО · </>}{new Date(item.published_at).toLocaleDateString("ru-RU")}</span></div>
    {item.cover_url && <div className="k7-story-cover"><img src={item.cover_url} alt="Обложка новости" loading="lazy" decoding="async"/></div>}
    {!!item.media_urls?.length && <div className="k7-publication-gallery">{item.media_urls.map((url,index)=><img key={`${url}-${index}`} src={url} alt={`Фото ${index+1}`} loading="lazy" decoding="async"/>)}</div>}
    <div className="k7-story-copy"><h3>{item.title}</h3>{item.subtitle && <p className="k7-story-subtitle">{item.subtitle}</p>}
      <EditorialBody value={item.content}/>
      {item.cta_label && item.cta_url && <a className="k7-story-cta" href={item.cta_url} target="_blank" rel="noopener noreferrer">{item.cta_label} <ExternalLink size={15}/></a>}
    </div>
    {canManage && <div className="k7-panel-card-actions k7-story-controls">
      <button type="button" className="k7-panel-button" onClick={() => onEdit(item)}><Edit3 size={13}/> <BrandLabel text={"РЕДАКТИРОВАТЬ"} asset="actions/edit" /></button>
      <button type="button" className="k7-panel-button" disabled={busy} onClick={() => onPin(item)}><Pin size={13}/> {item.is_pinned ? <BrandLabel text={"ОТКРЕПИТЬ"} asset="actions/unpin" /> : <BrandLabel text={"ЗАКРЕПИТЬ"} asset="actions/pin" />}</button>
      <button type="button" className="k7-panel-button" onClick={() => setConfirming(true)}><Trash2 size={13}/> <BrandLabel text={"УДАЛИТЬ"} asset="actions/delete" /></button>
    </div>}
    {confirming && <div className="k7-inline-confirm" role="group" aria-label="Подтверждение удаления"><span>Удалить «{item.title}» без возможности восстановления?</span><button type="button" disabled={busy} onClick={() => onDelete(item.id)}><BrandLabel text={"УДАЛИТЬ"} asset="actions/delete" /></button><button type="button" onClick={() => setConfirming(false)}><BrandLabel text={"ОТМЕНА"} asset="actions/cancel" /></button></div>}
  </article>;
}

export default function NewsStudio({ authReady, canManage, section="news" }: { authReady: boolean; canManage: boolean; section?: PublicationSection }) {
  const templates=sectionTemplates[section];
  const initial=()=>({...blank,category:templates[0].label,layoutStyle:templates[0].style});
  const [posts, setPosts] = useState<News[]>([]);
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  useEffect(() => { if (!notice) return; const timer=window.setTimeout(()=>setNotice(""),4000); return ()=>window.clearTimeout(timer); }, [notice]);
  const requestVersion = useRef(0);
  const [editorOpen, setEditorOpen] = useState(false);
  const [preview, setPreview] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [draft, setDraft] = useState<Draft>(initial);
  const [uploading,setUploading]=useState(false);
  const editorRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const patch = (partial: Partial<Draft>) => setDraft(old => ({ ...old, ...partial }));
  const reload = useCallback(async (silent = false) => {
    if (!authReady) return;
    const version = ++requestVersion.current;
    if (!silent) setLoading(true);
    try { const data = await json(`/api/news?section=${section}`); if(version!==requestVersion.current)return; setPosts(old=>stableSnapshot(old,data.news??[])); if(!silent)setError(""); }
    catch (err) { if(version===requestVersion.current&&!silent)setError(err instanceof Error ? err.message : "Не удалось загрузить новости"); }
    finally { if(version===requestVersion.current)setLoading(false); }
  }, [authReady,section]);
  useK7Sync(authReady, reload, 15000);
  function startNew() { setDraft(initial()); setEditingId(null); setEditorOpen(true); setPreview(false); requestAnimationFrame(()=>editorRef.current?.scrollIntoView({ behavior: "smooth", block: "nearest" })); }
  function startEdit(post: News) {
    setDraft({ mediaUrls:post.media_urls??[], title: post.title, subtitle: post.subtitle ?? "", category: post.category, content: post.content, coverUrl: post.cover_url ?? "", layoutStyle: post.layout_style, pinned: post.is_pinned, ctaLabel: post.cta_label ?? "", ctaUrl: post.cta_url ?? "" });
    setEditingId(post.id); setEditorOpen(true); setPreview(false);
    requestAnimationFrame(() => editorRef.current?.scrollIntoView({ behavior: "smooth", block: "start" }));
  }
  function insert(mark: "strong" | "italic" | "title" | "quote" | "list" | "link") {
    const textarea = textareaRef.current; if (!textarea) return;
    const a = textarea.selectionStart, b = textarea.selectionEnd;
    const selected = draft.content.slice(a,b) || "Текст";
    const token = mark === "strong" ? `**${selected}**` : mark === "italic" ? `*${selected}*` :
      mark === "title" ? `\n## ${selected}\n` : mark === "quote" ? `\n> ${selected}\n` :
      mark === "list" ? `\n- ${selected}` : `[${selected}](https://example.com)`;
    patch({ content: draft.content.slice(0,a) + token + draft.content.slice(b) });
    requestAnimationFrame(() => { textarea.focus(); textarea.setSelectionRange(a + token.length, a + token.length); });
  }
  async function save(event: FormEvent) {
    event.preventDefault(); if (saving || uploading) return;
    setSaving(true); setError(""); setNotice("");
    try {
      await json("/api/news", { method: editingId ? "PATCH" : "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ ...draft, section, ...(editingId ? { id: editingId } : {}) }) });
      setEditorOpen(false); setEditingId(null); setDraft(initial()); setNotice("Публикация сохранена"); await reload(true);
    } catch (err) { setError(err instanceof Error ? err.message : "Ошибка сохранения"); }
    finally { setSaving(false); }
  }
  async function remove(id: string) {
    setSaving(true); setError("");
    try { await json("/api/news", { method: "DELETE", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id }) });
      setPosts(old => old.filter(post => post.id !== id)); setNotice("Публикация удалена"); await reload(true); }
    catch (err) { setError(err instanceof Error ? err.message : "Ошибка удаления"); }
    finally { setSaving(false); }
  }
  async function togglePin(post: News) {
    setSaving(true); setError("");
    try { await json("/api/news", { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({
      id: post.id, section, mediaUrls:post.media_urls??[], title: post.title, content: post.content, subtitle: post.subtitle ?? "", category: post.category,
      coverUrl: post.cover_url ?? "", layoutStyle: post.layout_style, pinned: !post.is_pinned, ctaLabel: post.cta_label ?? "", ctaUrl: post.cta_url ?? "",
    }) }); await reload(true); }
    catch (err) { setError(err instanceof Error ? err.message : "Ошибка закрепления"); }
    finally { setSaving(false); }
  }
  const demo: News = { id: "preview", section, media_urls:draft.mediaUrls, title: draft.title || "Заголовок публикации", subtitle: draft.subtitle, category: draft.category, content: draft.content || "Текст появится здесь.", cover_url: draft.coverUrl || null, published_at: new Date().toISOString(), layout_style: draft.layoutStyle, is_pinned: draft.pinned, cta_label: draft.ctaLabel, cta_url: draft.ctaUrl };
  if(section!=="news"&&!canManage&&!posts.length)return null;
  return <div className="k7-data-panel k7-news-studio k7-section-publications">
    <div className="k7-panel-head"><div><div className="k7-panel-eyebrow"><BrandLabel text={"K7 / EDITORIAL TRANSMISSION"} asset="status/editorial_transmission" /></div><h2><BrandLabel text={section==="news"?"Новости":"Публикации"} asset={section==="news"?"nav/news":undefined} /></h2></div>
      </div>
    {canManage && <div className="k7-panel-toolbar"><button type="button" className="k7-panel-button k7-panel-primary" disabled={uploading||saving} onClick={startNew}><Plus size={15}/> <BrandLabel text={"СОЗДАТЬ ПУБЛИКАЦИЮ"} asset="actions/create_publication" /></button></div>}
    <div ref={editorRef}/>
    {canManage && editorOpen && <div className="k7-editor-studio">
      <div className="k7-editor-head"><span>{editingId ? <BrandLabel text={"РЕДАКТИРОВАНИЕ"} asset="sections/editing" /> : <BrandLabel text={"НОВАЯ ПУБЛИКАЦИЯ"} asset="sections/new_publication" />}</span><button type="button" disabled={uploading||saving} onClick={() => setEditorOpen(false)} aria-label="Закрыть редактор"><X size={19}/><BrandLabel text="Закрыть редактор" asset="actions/close_editor" /></button></div>
      <form onSubmit={(event) => void save(event)} className="k7-panel-form k7-editor-form">
        <label className="k7-panel-wide">Фирменный шаблон<select value={draft.category} onChange={event=>{const template=templates.find(t=>t.label===event.target.value);if(template)patch({category:template.label,layoutStyle:template.style});}}>{!templates.some(t=>t.label===draft.category)&&<option value={draft.category}>{draft.category} (ранее опубликовано)</option>}{templates.map(t=><option key={t.label} value={t.label}>{t.label}</option>)}</select></label>
        <label className="k7-panel-wide"><BrandLabel text={"Заголовок"} asset="fields/headline" /><input maxLength={150} required value={draft.title} onChange={event => patch({ title: event.target.value })} placeholder="Главная мысль публикации" /></label>
        <label className="k7-panel-wide"><BrandLabel text={"Подзаголовок"} asset="actions/subtitle" /><input maxLength={220} value={draft.subtitle} onChange={event => patch({ subtitle: event.target.value })} placeholder="Короткое выразительное вступление" /></label>
        <div className="k7-panel-wide"><BrandLabel text="Фотографии"/><K7PhotoUpload max={6-draft.mediaUrls.length} disabled={saving} onBusy={setUploading} onUpload={urls=>setDraft(old=>({...old,mediaUrls:[...old.mediaUrls,...urls].slice(0,6)}))}/><div className="k7-publication-gallery">{draft.mediaUrls.map((url,index)=><div key={`${url}-${index}`}><img src={url} alt={`Фото ${index+1}`}/><button type="button" onClick={()=>patch({mediaUrls:draft.mediaUrls.filter((_,i)=>i!==index)})}>Удалить фото</button></div>)}</div>{draft.coverUrl&&<div><img className="k7-panel-cover" src={draft.coverUrl} alt="Текущая обложка"/><button type="button" onClick={()=>patch({coverUrl:""})}>Удалить обложку</button></div>}</div>
        <div className="k7-panel-wide k7-editor-composer"><div className="k7-editor-toolbar"><button type="button" title="Жирный" onClick={() => insert("strong")}><Bold size={16}/><BrandLabel text="Жирный" asset="actions/bold" /></button><button type="button" title="Курсив" onClick={() => insert("italic")}><Italic size={16}/><BrandLabel text="Курсив" asset="actions/italic" /></button><button type="button" title="Подзаголовок" onClick={() => insert("title")}><Heading2 size={16}/><BrandLabel text="Подзаголовок" asset="actions/subtitle" /></button><button type="button" title="Цитата" onClick={() => insert("quote")}><Quote size={16}/><BrandLabel text="Цитата" asset="actions/quote" /></button><button type="button" title="Список" onClick={() => insert("list")}><List size={16}/><BrandLabel text="Список" asset="actions/list" /></button><button type="button" title="HTTPS-ссылка" onClick={() => insert("link")}><ExternalLink size={16}/><BrandLabel text="HTTPS-ссылка" asset="actions/https_link" /></button></div>
          <label><BrandLabel text={"Текст публикации"} asset="fields/publication_text" /><textarea ref={textareaRef} rows={8} required maxLength={20000} value={draft.content} onChange={event => patch({ content: event.target.value })} placeholder="Расскажи историю команды, выдели ключевые детали..."/><small>{draft.content.length} / 20000</small></label></div>
        <label><BrandLabel text={"Кнопка действия"} asset="fields/cta" /><input maxLength={48} value={draft.ctaLabel} onChange={event => patch({ ctaLabel: event.target.value })} placeholder="Например: Подробнее" /></label>
        <label><BrandLabel text={"Ссылка кнопки (HTTPS)"} asset="fields/cta_url" /><input type="url" value={draft.ctaUrl} onChange={event => patch({ ctaUrl: event.target.value })} placeholder="https://..." /></label>
        <label className="k7-editor-pin"><input type="checkbox" checked={draft.pinned} onChange={event => patch({ pinned: event.target.checked })}/> <BrandLabel text={"Закрепить публикацию наверху"} asset="fields/pin_top" /></label>
        <div className="k7-panel-wide k7-editor-actions"><button type="button" className="k7-panel-button" onClick={() => setPreview(old => !old)}><Eye size={16}/> {preview ? <BrandLabel text={"СКРЫТЬ ПРЕВЬЮ"} asset="actions/hide_preview" /> : <BrandLabel text={"ПРЕДПРОСМОТР"} asset="actions/preview" />}</button><button type="submit" className="k7-panel-button k7-panel-primary" disabled={saving || uploading || !draft.title.trim() || !draft.content.trim()}>{saving ? <BrandLabel text={"СОХРАНЯЕМ..."} asset="actions/saving_news" /> : editingId ? <BrandLabel text={"СОХРАНИТЬ ИЗМЕНЕНИЯ"} asset="actions/save_changes" /> : <BrandLabel text={"ОПУБЛИКОВАТЬ"} asset="actions/publish" />}</button></div>
      </form>
      {preview && <div className="k7-editor-preview"><span><BrandLabel text={"ПРЕДПРОСМОТР"} asset="actions/preview" /></span><NewsCard item={demo} canManage={false} onDelete={() => {}} onEdit={() => {}} onPin={() => {}} busy={false}/></div>}
    </div>}
    {error && <div className="k7-panel-error" role="alert">{error}</div>}
    {notice && <div className="k7-panel-notice" role="status">{notice}</div>}
    {!authReady && <div className="k7-panel-empty"><BrandLabel text={"Войдите через Telegram"} asset="status/telegram_required" /></div>}
    {loading && !posts.length && <div className="k7-panel-empty">Загрузка публикаций...</div>}
    {authReady && !loading && posts.length === 0 && !error && <div className="k7-panel-empty">Публикаций пока нет</div>}
    <div className="k7-news-feed">{posts.map(post => <NewsCard key={post.id} item={post} canManage={canManage} onEdit={startEdit} onDelete={(id) => void remove(id)} onPin={(item) => void togglePin(item)} busy={saving}/>)}</div>
  </div>;
}
